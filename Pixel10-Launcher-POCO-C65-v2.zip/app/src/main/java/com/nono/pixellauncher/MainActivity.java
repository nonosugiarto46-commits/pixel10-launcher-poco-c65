package com.nono.pixellauncher;

import android.app.Activity;
import android.app.SearchManager;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(16,17,22), PANEL = Color.rgb(34,35,43);
    private final int TEXT = Color.rgb(242,239,247), MUTED = Color.rgb(190,184,202);
    private LinearLayout root, content;
    private boolean drawer = false;
    private float downY, downX;
    private List<ApplicationInfo> apps = new ArrayList<>();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        loadApps();
        showHome();
    }

    private void loadApps() {
        apps = getPackageManager().getInstalledApplications(PackageManager.GET_META_DATA);
        Collections.sort(apps, new Comparator<ApplicationInfo>() {
            public int compare(ApplicationInfo a, ApplicationInfo b) {
                return getPackageManager().getApplicationLabel(a).toString()
                    .compareToIgnoreCase(getPackageManager().getApplicationLabel(b).toString());
            }
        });
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView label(String s, int size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER);
        return t;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private void base(String title) {
        root = column(); root.setBackgroundColor(BG); root.setPadding(22,18,22,12);
        setContentView(root);
        root.setAlpha(0f); root.setTranslationY(18f);
        root.animate().alpha(1f).translationY(0f).setDuration(220).start();
        TextView top = label(title,14,MUTED);
        top.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        root.addView(top,new LinearLayout.LayoutParams(-1,34));
        content = column(); root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
    }
    private void showHome() {
        drawer=false; base("◉   PIXEL 10"); content.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView date=label(new SimpleDateFormat("EEEE, d MMMM",new Locale("id","ID")).format(new Date()),15,MUTED);
        LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(-1,42); dp.topMargin=38; content.addView(date,dp);
        TextView clock=label(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date()),68,TEXT);
        clock.setTypeface(Typeface.create("sans-serif-light",Typeface.NORMAL));
        content.addView(clock,new LinearLayout.LayoutParams(-1,90));
        content.addView(label("Selamat datang",15,MUTED),new LinearLayout.LayoutParams(-1,32));
        View spacer=new View(this); content.addView(spacer,new LinearLayout.LayoutParams(1,0,1));
        content.addView(label("Geser ke atas untuk semua aplikasi",13,MUTED),new LinearLayout.LayoutParams(-1,34));
        EditText homeSearch=new EditText(this); homeSearch.setSingleLine(true);
        homeSearch.setTextColor(TEXT); homeSearch.setHintTextColor(MUTED); homeSearch.setHint("⌕   Cari aplikasi");
        homeSearch.setTextSize(16); homeSearch.setPadding(20,0,20,0); homeSearch.setBackground(shape(PANEL,48));
        content.addView(homeSearch,new LinearLayout.LayoutParams(-1,54));
        homeSearch.setOnEditorActionListener((v,a,e)->{String q=homeSearch.getText().toString(); if(!q.trim().isEmpty()) openSearch(q); return true;});
        TextView dock=label("◉        ●        ◉        ●",25,TEXT);
        LinearLayout.LayoutParams dockp=new LinearLayout.LayoutParams(-1,66); dockp.topMargin=10; content.addView(dock,dockp);
        root.setOnTouchListener(gestureListener()); content.setOnTouchListener(gestureListener());
    }
    private void showDrawer(String filter) {
        drawer=true; base("Semua aplikasi");
        EditText search=new EditText(this); search.setSingleLine(true);
        search.setTextColor(TEXT); search.setHintTextColor(MUTED); search.setHint("Cari aplikasi");
        search.setTextSize(16); search.setPadding(18,0,18,0); search.setBackground(shape(PANEL,40));
        content.addView(search,new LinearLayout.LayoutParams(-1,52));
        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true); scroll.setVerticalScrollBarEnabled(true);
        GridLayout grid=new GridLayout(this); grid.setColumnCount(4); grid.setPadding(0,18,0,0);
        scroll.addView(grid,new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT));
        content.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        populate(grid,filter);
        search.setText(filter); search.setSelection(search.length());
        search.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a) {}
            public void onTextChanged(CharSequence s,int st,int before,int count) { populate(grid,s.toString()); scroll.scrollTo(0,0); }
            public void afterTextChanged(android.text.Editable e) {}
        });
        // Do not intercept ScrollView touch events: vertical scrolling stays enabled.
        root.setOnTouchListener(null);
    }
    private void populate(GridLayout grid,String filter) {
        grid.removeAllViews(); String q=filter==null?"":filter.toLowerCase(Locale.ROOT);
        PackageManager pm=getPackageManager();
        for(ApplicationInfo app:apps) {
            String name=pm.getApplicationLabel(app).toString();
            if(!app.packageName.equals(getPackageName()) && name.toLowerCase(Locale.ROOT).contains(q)) {
                LinearLayout item=column(); item.setGravity(Gravity.CENTER); item.setPadding(6,12,6,16);
                try {
                    ImageView icon=new ImageView(this); icon.setImageDrawable(pm.getApplicationIcon(app));
                    item.addView(icon,new LinearLayout.LayoutParams(64,64));
                } catch(Exception ignored) {}
                TextView title=label(name,13,TEXT); title.setMaxLines(2);
                item.addView(title,new LinearLayout.LayoutParams(-1,42));
                item.setOnClickListener(v->{Intent launch=pm.getLaunchIntentForPackage(app.packageName); if(launch!=null) startActivity(launch);});
                GridLayout.LayoutParams p=new GridLayout.LayoutParams();
                p.width=0; p.height=ViewGroup.LayoutParams.WRAP_CONTENT;
                p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f); grid.addView(item,p);
            }
        }
    }
    private View.OnTouchListener gestureListener() {
        return (v,e)->{
            if(e.getAction()==MotionEvent.ACTION_DOWN){downY=e.getY();downX=e.getX();return true;}
            if(e.getAction()==MotionEvent.ACTION_UP){
                float dy=e.getY()-downY,dx=e.getX()-downX;
                if(Math.abs(dy)>85 && Math.abs(dy)>Math.abs(dx)){
                    if(dy<0 && !drawer) showDrawer("");
                    else if(dy>0 && drawer) showHome();
                    return true;
                }
            } return true;
        };
    }
    private void openSearch(String q) {
        try { Intent i=new Intent(Intent.ACTION_WEB_SEARCH); i.putExtra(SearchManager.QUERY,q); startActivity(i); }
        catch(Exception e) { showDrawer(q); }
    }
    @Override public void onBackPressed(){if(drawer)showHome();else super.onBackPressed();}
    @Override protected void onResume(){super.onResume();loadApps();if(!drawer&&root!=null)showHome();}
}
