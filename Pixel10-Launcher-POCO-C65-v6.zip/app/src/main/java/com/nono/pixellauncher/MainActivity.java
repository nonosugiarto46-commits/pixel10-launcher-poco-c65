package com.nono.pixellauncher;
import android.app.*; import android.app.SearchManager; import android.content.*; import android.content.pm.*; import android.graphics.*; import android.graphics.drawable.*; import android.os.*; import android.view.*; import android.widget.*; import java.text.*; import java.util.*;
public class MainActivity extends Activity {
 static final int REQ_WALLPAPER_IMAGE=501;
 int BG=Color.rgb(16,17,22), PANEL=Color.rgb(34,35,43), TEXT=Color.rgb(242,239,247), MUTED=Color.rgb(190,184,202);
 LinearLayout root,content; boolean drawer=false; float downY,downX; List<ApplicationInfo> apps=new ArrayList<>();
 int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
  getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER);
  getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
  loadApps();showHome();}
 void loadApps(){apps=new ArrayList<>();PackageManager pm=getPackageManager();for(ApplicationInfo a:pm.getInstalledApplications(PackageManager.GET_META_DATA)){if(pm.getLaunchIntentForPackage(a.packageName)!=null&&!a.packageName.equals(getPackageName()))apps.add(a);}Collections.sort(apps,(a,b)->pm.getApplicationLabel(a).toString().compareToIgnoreCase(pm.getApplicationLabel(b).toString()));}
 GradientDrawable shape(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
 TextView label(String s,int z,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);t.setGravity(Gravity.CENTER);return t;}
 LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
 void base(String title){
  root=column();
  root.setBackgroundColor(Color.TRANSPARENT);
  root.setPadding(dp(20),dp(14),dp(20),dp(10));
  setContentView(root);

  TextView top=label(title,14,MUTED);
  top.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
  root.addView(top,new LinearLayout.LayoutParams(-1,dp(34)));

  // Create content BEFORE attaching long-press listeners.
  content=column();
  root.addView(content,new LinearLayout.LayoutParams(-1,0,1));

  View.OnLongClickListener wallpaperListener=v->{
    showWallpaperOptions();
    return true;
  };
  root.setLongClickable(true);
  root.setOnLongClickListener(wallpaperListener);
  content.setLongClickable(true);
  content.setOnLongClickListener(wallpaperListener);

  root.setAlpha(0f);
  root.setTranslationY(dp(12));
  root.animate().alpha(1f).translationY(0f).setDuration(220).start();
}
 void showHome(){drawer=false;base("◉   PIXEL 10");content.setGravity(Gravity.CENTER_HORIZONTAL);TextView date=label(new SimpleDateFormat("EEEE, d MMMM",new Locale("id","ID")).format(new Date()),16,MUTED);LinearLayout.LayoutParams d=new LinearLayout.LayoutParams(-1,dp(42));d.topMargin=dp(36);content.addView(date,d);TextView clock=label(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date()),68,TEXT);clock.setTypeface(Typeface.create("sans-serif-light",0));content.addView(clock,new LinearLayout.LayoutParams(-1,dp(92)));content.addView(label("Selamat datang",15,MUTED),new LinearLayout.LayoutParams(-1,dp(32)));View spacer=new View(this);content.addView(spacer,new LinearLayout.LayoutParams(1,0,1));content.addView(label("Geser ke atas untuk semua aplikasi",14,MUTED),new LinearLayout.LayoutParams(-1,dp(34)));EditText s=new EditText(this);s.setSingleLine(true);s.setTextColor(TEXT);s.setHintTextColor(MUTED);s.setHint("⌕   Cari aplikasi");s.setTextSize(16);s.setPadding(dp(20),0,dp(20),0);s.setBackground(shape(PANEL,48));content.addView(s,new LinearLayout.LayoutParams(-1,dp(54)));s.setOnEditorActionListener((v,a,e)->{String q=s.getText().toString();if(!q.trim().isEmpty())openSearch(q);return true;});}

 void showWallpaperOptions(){
  new AlertDialog.Builder(this).setTitle("Wallpaper & gaya")
   .setItems(new String[]{"Pilih gambar dari galeri"},(dialog,which)->{
    try{
     Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);
     pick.addCategory(Intent.CATEGORY_OPENABLE);
     pick.setType("image/*");
     startActivityForResult(pick,REQ_WALLPAPER_IMAGE);
    }catch(Exception e){
     Toast.makeText(this,"Galeri tidak tersedia di perangkat ini",Toast.LENGTH_LONG).show();
    }
   }).show();
 }
 @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
  super.onActivityResult(requestCode,resultCode,data);
  if(requestCode==REQ_WALLPAPER_IMAGE && resultCode==RESULT_OK && data!=null && data.getData()!=null){
   android.net.Uri uri=data.getData();
   try{
    android.graphics.BitmapFactory.Options bounds=new android.graphics.BitmapFactory.Options();
    bounds.inJustDecodeBounds=true;
    java.io.InputStream first=getContentResolver().openInputStream(uri);
    android.graphics.BitmapFactory.decodeStream(first,null,bounds);
    if(first!=null) first.close();
    int screenW=getResources().getDisplayMetrics().widthPixels;
    int screenH=getResources().getDisplayMetrics().heightPixels;
    int sample=1;
    while(bounds.outWidth/(sample*2)>=screenW && bounds.outHeight/(sample*2)>=screenH) sample*=2;
    android.graphics.BitmapFactory.Options opts=new android.graphics.BitmapFactory.Options();
    opts.inSampleSize=sample;
    java.io.InputStream second=getContentResolver().openInputStream(uri);
    android.graphics.Bitmap bitmap=android.graphics.BitmapFactory.decodeStream(second,null,opts);
    if(second!=null) second.close();
    if(bitmap==null) throw new Exception("Gambar tidak dapat dibaca");
    android.app.WallpaperManager wm=android.app.WallpaperManager.getInstance(this);
    if(android.os.Build.VERSION.SDK_INT>=24){
     wm.setBitmap(bitmap,null,true,android.app.WallpaperManager.FLAG_SYSTEM);
    }else{
     wm.setBitmap(bitmap);
    }
    bitmap.recycle();
    Toast.makeText(this,"Wallpaper layar utama berhasil diganti",Toast.LENGTH_LONG).show();
   }catch(Exception e){
    Toast.makeText(this,"Gagal memasang wallpaper: "+e.getMessage(),Toast.LENGTH_LONG).show();
   }
  }
 }
 void showDrawer(String filter){drawer=true;base("Semua aplikasi");EditText search=new EditText(this);search.setSingleLine(true);search.setTextColor(TEXT);search.setHintTextColor(MUTED);search.setHint("Cari aplikasi");search.setTextSize(16);search.setPadding(dp(18),0,dp(18),0);search.setBackground(shape(PANEL,40));content.addView(search,new LinearLayout.LayoutParams(-1,dp(52)));ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.setVerticalScrollBarEnabled(true);scroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);GridLayout grid=new GridLayout(this);grid.setColumnCount(4);grid.setPadding(0,dp(14),0,dp(24));scroll.addView(grid,new ScrollView.LayoutParams(-1,-2));content.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));populate(grid,filter);search.setText(filter==null?"":filter);search.setSelection(search.length());search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int n){populate(grid,s.toString());scroll.scrollTo(0,0);}public void afterTextChanged(android.text.Editable e){}});}
 void populate(GridLayout grid,String filter){grid.removeAllViews();String q=filter==null?"":filter.toLowerCase(Locale.ROOT);PackageManager pm=getPackageManager();for(ApplicationInfo app:apps){String name=pm.getApplicationLabel(app).toString();if(name.toLowerCase(Locale.ROOT).contains(q)){LinearLayout item=column();item.setGravity(Gravity.CENTER);item.setPadding(dp(4),dp(10),dp(4),dp(12));ImageView icon=new ImageView(this);icon.setImageDrawable(pm.getApplicationIcon(app));icon.setScaleType(ImageView.ScaleType.FIT_CENTER);item.addView(icon,new LinearLayout.LayoutParams(dp(76),dp(76)));TextView title=label(name,13,TEXT);title.setMaxLines(2);title.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);title.setPadding(0,dp(5),0,0);item.addView(title,new LinearLayout.LayoutParams(-1,dp(42)));item.setOnClickListener(v->{Intent i=pm.getLaunchIntentForPackage(app.packageName);if(i!=null)startActivity(i);});GridLayout.LayoutParams p=new GridLayout.LayoutParams();p.width=0;p.height=-2;p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);grid.addView(item,p);}}}
 @Override public boolean dispatchTouchEvent(MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN){downY=e.getY();downX=e.getX();}else if(e.getAction()==MotionEvent.ACTION_UP&&!drawer){float dy=e.getY()-downY,dx=e.getX()-downX;if(dy < -dp(70)&&Math.abs(dy)>Math.abs(dx)*1.2f){super.dispatchTouchEvent(e);showDrawer("");return true;}}return super.dispatchTouchEvent(e);}
 void openSearch(String q){try{Intent i=new Intent(Intent.ACTION_WEB_SEARCH);i.putExtra(SearchManager.QUERY,q);startActivity(i);}catch(Exception e){showDrawer(q);}}
 @Override public void onBackPressed(){if(drawer)showHome();else super.onBackPressed();}
 @Override protected void onResume(){super.onResume();loadApps();}
}